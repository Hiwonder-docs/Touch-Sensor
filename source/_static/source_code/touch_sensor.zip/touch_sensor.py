#!/usr/bin/env python3

import Jetson.GPIO as GPIO
import time

"""
触摸传感器读取实验
触摸传感器是简单的数字io传感器， 只要读取对应IO口的电平变化即可

需要注意当触摸传感器没被按下时输出高电平， 被按下输出低电平
"""


def main():
    #初始化io口
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(10, GPIO.IN)

    while True:
        state = GPIO.input(10)
        print("OUT:",state) #打印IO口信息
        time.sleep(0.5) #500毫秒刷新一次按钮状态

if __name__ == '__main__':
    main()
